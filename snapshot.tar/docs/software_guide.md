# 肝癌生信软件使用指南

本目录不仅提供命令行脚本，也可以通过一个统一的入口使用。`liverbio` 只负责转发参数，不会改变任何原有脚本的实际行为；原有 `launchers`、网页端和 `scripts/run_*.py` 仍可直接使用。

## 新电脑部署

Windows 新电脑建议从项目根目录运行：

```text
setup_new_computer.bat
check_new_computer.bat
```

Linux/macOS 使用同名的 `.sh`。需要携带干净源码时，在当前电脑运行：

```text
liverbio package
```

生成的 zip 位于 `portable/`，只包含 git 跟踪的源码文件，不含本机结果、
缓存、日志和下载工具。详细说明见根目录 `NEW_COMPUTER_SETUP.md`。

## 统一入口

Windows 下在项目根目录打开命令提示符或 PowerShell：

```text
liverbio help
liverbio version
```

`liverbio.bat` 位于项目根目录。若希望在任何目录直接使用，可把项目根目录加入 `PATH`。

主要命令：

```text
liverbio expression GSE125449 --output ../liver_cancer --species auto
liverbio full --accession GSE125449 --output ../liver_cancer --workdir ../liver_cancer_full
liverbio docking pipeline --config config/docking_config.json
liverbio datasets --disease "liver cancer" --max-results 20
liverbio evidence --disease NAFLD --targets GPAT3,PPP2R2A --output ../evidence_run
liverbio advanced --config config/advanced_analysis.json --output <OUTPUT_DIR>/advanced
liverbio mr --config config/mr_coloc.json --output <OUTPUT_DIR>/mr
liverbio web --page full
liverbio analysis-export GSE235863
liverbio doctor
liverbio setup
liverbio package
```

每条命令后面的参数与原脚本完全一致。对某个功能需要查看详细参数时，先查看原脚本帮助：

```text
python scripts\run_pipeline.py --help
python scripts\run_docking.py <子命令> --help
python scripts\run_full_pipeline.py --help
python scripts\search_datasets.py --help
```

### 导出到本地分析工作区

第一次使用 `--remember-analysis-root` 记住 `<ANALYSIS_ROOT>`，之后只需要数据集编号：

```text
liverbio analysis-export GSE235863 --analysis-root <ANALYSIS_ROOT> --remember-analysis-root
liverbio analysis-export GSE235863
launchers\export_to_analysis.bat GSE235863
```

命令会从 `<ANALYSIS_ROOT>\config\local_projects.json` 已登记的 `output_roots`
自动定位运行目录，把结果增量写入 `data/imported_results`，并刷新 `_inventory.json`。

### 高级多队列与 MR

`liverbio advanced` 读取一个 discovery cohort 和任意数量的 validation cohorts，执行 ComBat/limma（R 可用时）、WGCNA、基因级多模型比较、外部验证、免疫和生存分析，并输出 `integrated_priority.csv`。证据文件建议显式填写 `score_column`，最小配置可复制 `config/advanced_analysis.example.json`。

`liverbio mr` 读取本地 eQTL 和 GWAS summary statistics，执行距离剪枝或 PLINK LD clumping，并处理回文 SNP 的链方向问题；随后执行 IVW、weighted median、MR-Egger、异质性、Egger intercept 和 leave-one-out，R 包存在时追加 MendelianRandomization 和 coloc 结果。输入列映射见 `config/mr_coloc.example.json`。

### 多数据库证据中心

`liverbio evidence` 把 Open Targets、ChEMBL、BindingDB、PubChem BioAssay、GWAS Catalog、ClinVar、GTEx 和 HPA 等来源写入统一 SQLite 证据库，并输出目标优先级、证据矩阵和来源消融结果。全自动流水线还会把疾病/遗传证据发现的非 DEG 靶点并入扩展候选宇宙，并将旧版 ChEMBL、PDB、AlphaFold、Reactome 和 KEGG 证据标准化后参与排序。DepMap、CTD、Tox21/ToxCast、LINCS、DisGeNET、cBioPortal、OncoKB、CIViC、ClinicalTrials.gov 及授权数据库通过 `config/evidence_local_sources.example.json` 的本地表映射接入。详细说明见 `docs/evidence_hub.md`。

网页版与命令行共用同一组入口：`/analysis` 可独立运行高级多队列分析、MR/共定位和结果导出；`/validation` 可选择随机 GSE 全流程、TCGA/GSE165816 多队列、真实 PDB 证据或随机证据/对接盒验证；全自动流水线可通过 `--advanced-priority-csv` 使用上一轮 `integrated_priority.csv` 调整关键基因排序。

## 常用工作流

### 打开网页软件

```text
liverbio web
```

默认打开 `http://127.0.0.1:8000/full`。可使用 `--page dock`、
`--page md-simulation`、`--page knockout`、`--page network`、
`--page faers`、`--page validation`、`--page analysis`、
`--page molecular-docking`、
`--page datasets`、`--page results`、`--page tasks`、
`--page guide`、`--page environment` 等打开对应页面。

网页服务默认绑定回环地址 `127.0.0.1`，无需认证；用 `--host` 绑定非回环地址时会自动生成会话 token，必须通过带 `?token=...` 的 URL 或 `X-Auth-Token` 请求头访问。结果浏览默认只允许读取项目输出根目录和本控制台启动过的任务目录，其他目录需用 `--allow-path <目录>` 显式放行。

网页顶部提供“使用教程”与“环境补全”两个独立入口：

- `/guide`：网页版使用教程，包含页面速查表、首次补全、标准运行流程、任务管理与结果查看。
- `/environment`：按功能板块检查并一键补全环境，可填写自定义安装地址或勾选同时安装 ML/DL 依赖。

也可以在各功能页内直接使用原有的“检查环境 / 自动补全”区域；新电脑建议先打开
`/environment`，只补全实际使用板块的依赖，再进入对应分析页面。

### 检查运行环境

```text
liverbio doctor
liverbio doctor pipeline
liverbio doctor docking
```

`liverbio doctor` 按顺序执行表达分析和虚拟筛选环境检查；缺少组件时按输出提示运行 `launchers` 下的安装脚本。

### 按板块补全环境

新电脑可按实际功能板块只补全对应环境：

```text
launchers\install_expression_environment.bat        # 表达分析
launchers\install_datasets_environment.bat           # 数据集搜索
launchers\install_analysis_environment.bat           # 高级分析 / MR / 共定位
launchers\install_docking_environment.bat            # 虚拟筛选 / 对接
launchers\install_molecular_docking_environment.bat  # 独立分子对接
launchers\install_md_environment.bat                 # 分子动力学
launchers\install_full_environment.bat               # 全自动集成流水线
launchers\install_web_environment.bat                # 网页版
launchers\install_codex_skills_environment.bat       # Codex Skills
```

统一命令支持模块名和检查：

```text
python launchers\install_environment.py list
python launchers\install_environment.py install expression
python launchers\install_environment.py check docking
python launchers\install_environment.py check full
```

表达分析补全时，如果 Windows 上找不到 `Rscript`，脚本会自动下载 R 到当前用户目录并安装 R 包；对接板块会自动补全 AutoDockTools 和 AutoDock Vina。ML/DL 依赖使用 `--with-ml` 额外安装。

按功能板块查看“运行哪个入口、需要哪些软件和脚本”：`docs/environment_requirements.md`。

## Codex Skills

`skills/` 目录保存按功能拆分的 Codex skill 定义：

- `liver-expression-analysis`：表达分析。
- `liver-virtual-screening`：虚拟筛选。
- `liver-full-pipeline`：全自动集成流水线。
- `liver-dataset-search`：数据集搜索与下载。

安装到当前用户的 Codex skill 目录：

```text
python scripts\install_codex_skills.py
python scripts\install_codex_skills.py --force
```

Skill 只是指导 Codex 调用本项目现有脚本，不复制或替代核心分析代码。

## 目录结构

```text
scripts\         命令行入口
src\             可复用 Python 模块
  common\        环境与通用工具
  data\          数据下载、转换与校验
  pipeline\      表达分析、全流程编排
    qc.py           QC 门控
    differential.py 差异丰度
    key_targets.py  关键基因排序
  docking\       虚拟筛选、靶点评分
  report\        结果报告
  liverbio_suite\ 统一命令入口
web\             本地网页软件
  web_analysis.py   高级分析与 MR/导出任务
  web_validation.py 真实数据验证任务
  web_files.py      结果文件发现
skills\          Codex skill 源文件
launchers\       Windows 快捷启动与安装脚本
config\          默认配置
tests\           单元与集成测试
```

优化原则：优先复用现有已测试模块；不通过复制代码方式“打包”，而是用统一入口、环境检查和文档把现有功能组织成软件。
