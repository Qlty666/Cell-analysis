"""Data acquisition module."""
