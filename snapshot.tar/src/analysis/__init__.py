"""R analysis scripts module."""
