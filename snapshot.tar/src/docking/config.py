#!/usr/bin/env python3
"""Load, validate and serialize docking configuration."""

from __future__ import annotations

import copy
import json
import os
from pathlib import Path

try:
    import yaml
except ImportError:  # YAML configs are optional; JSON is the default format.
    yaml = None

DEFAULTS = {
    "name": "liver_cancer_vs",
    "workdir": ".",
    "output_dir": "outputs/run_001",
    "receptor": {
        "input": "data/receptors/receptor.pdb",
        "output": "data/receptors/receptor.pdbqt",
        "detect_input": None,
        "center": [0.0, 0.0, 0.0],
        "size": [22.5, 22.5, 22.5],
        "flexible": [],
    },
    "ligand": {
        "input": "data/ligands/library.sdf",
        "output_dir": "data/ligands/prepared",
        "smiles_column": "SMILES",
        "id_column": "ID",
        "ph": 7.4,
        "remove_salts": True,
        "neutralize": True,
        "max_heavy_atoms": 60,
        "max_rotatable_bonds": 15,
        "max_ligands": None,
        "conformers": 1,
        "seed": 42,
        "engine": "auto",
    },
    "docking": {
        "engine": "vina",
        "executable": "vina",
        "scoring": "vina",
        "exhaustiveness": 8,
        "num_modes": 9,
        "energy_range": 3.0,
        "cpu": 4,
        "max_workers": 4,
        "seed": 42,
        "seeds": [],
        "replicates": 1,
        "positive_control_pdbqt": None,
        "positive_control_id": "positive_control",
        "positive_control_max_affinity": None,
        "timeout_seconds": 600,
        "resume": True,
    },
    "analysis": {
        "cutoff": -7.0,
        "moderate_cutoff": -5.0,
        "top_n": 100,
        "figures": True,
        "diversity": True,
        "tanimoto_cutoff": 0.7,
    },
    "evidence": {
        "uniprot_accession": None,
        "pdb_id": None,
        "chembl_target_id": None,
        "target_name": None,
        "ligand_name": None,
        "ligand_smiles": None,
        "max_items": 10,
    },
    "ml": {
        "model": "rf",
        "task": "auto",
        "label_column": "active",
        "training_csv": "data/ml/training.csv",
        "test_size": 0.2,
        "random_state": 42,
        "epochs": 80,
        "hidden_size": 128,
    },
    "md": {
        "export_dir": "outputs/md",
        "top_n": 10,
    },
    "md_simulation": {
        "mode": "prepare",
        "executable": None,
        "gmx_data_dir": None,
        "top_n": 1,
        "receptor_pdb": None,
        "protein_forcefield": "amber99sb-ildn",
        "water": "tip3p",
        "box_type": "cubic",
        "box_padding_nm": 1.2,
        "ion_concentration": 0.15,
        "ligand_charge": 0,
        "ligand_forcefield": "gaff2",
        "topology_dir": None,
        "em_steps": 5000,
        "equil_steps": 250000,
        "prod_steps": 25000000,
        "dt_ps": 0.002,
        "gen_seed": 42,
        "temperature": 300,
        "pressure": 1.0,
        "timeout_seconds": 86400,
        "cpu": 4,
        "gpu": False,
        "figures": True,
        "maxwarn": 20,
        "contact_cutoff_nm": 0.6,
        "equilibrate_fraction": 0.5,
        "mmpbsa_command": None,
        "mmpbsa_timeout_seconds": 7200,
        "rmsd_stable_std_nm": 0.15,
        "rg_stable_std_nm": 0.05,
        "sasa_stable_std_nm2": 1.0,
    },
    "redock": {
        "enabled": True,
        "top_n": 20,
        "exhaustiveness": 32,
        "num_modes": 9,
        "energy_range": 3.0,
        "max_workers": 4,
        "timeout_seconds": 600,
        "resume": True,
    },
    "report": {
        "top_n": 20,
    },
    "knockout": {
        "enabled": True,
        "expression_csv": "data/knockout/expression.csv",
        "metadata_csv": None,
        "ppi_network_csv": None,
        "depmap_csv": None,
        "prognosis_csv": None,
        "druggability_csv": None,
        "off_target_csv": None,
        "group_column": "condition",
        "cell_type_column": None,
        "case_label": None,
        "normal_label": None,
        "top_n": 50,
        "figures": True,
        "max_genes": 2000,
        "max_samples": 5000,
        "corr_cutoff": 0.7,
        "liver_lineage": "liver",
        "off_target_penalty": 0.05,
        "disease_up_genes": None,
        "disease_down_genes": None,
        "pathway_genes": None,
        "weights": {
            "expression": 0.35,
            "proliferation": 0.25,
            "network": 0.20,
            "depmap": 0.20,
        },
        "target_weights": {
            "base": 0.35,
            "reversal": 0.20,
            "pathway": 0.15,
            "specificity": 0.10,
            "prognosis": 0.10,
            "druggability": 0.10,
            "ppi_hub": 0.10,
        },
    },
    "insilico_knockout": {
        "enabled": False,
        "ko_gene": None,
        "engine": "auto",
        "raw_count_input": None,
        "species": "auto",
        "embedding_csv": None,
        "regulators_csv": None,
        "min_cells": 100,
        "max_cells": 5000,
        "max_genes": 1800,
        "seed": 123,
        "knn_impute_neighbors": 66,
        "n_propagation": 3,
        "network_edges_per_regulator": 300,
        "target_top_n": 15,
        "bar_top_n": 8,
        "run_enrichment": True,
        "enrichment_genes": 150,
        "enrichment_timeout": 900,
        "gene_note": None,
        "photo_output_dir": None,
        "figures": True,
        "scTenifold_min_lib_size": 1000,
        "scTenifold_remove_outlier_cells": True,
        "scTenifold_min_percent": 0.05,
        "scTenifold_max_mito_ratio": 0.1,
        "scTenifold_min_exp_avg": 0.05,
        "scTenifold_min_exp_sum": 25,
        "scTenifold_n_networks": 5,
        "scTenifold_n_cells": 500,
        "scTenifold_n_comp": 3,
        "scTenifold_q": 0.95,
        "scTenifold_K": 3,
        "scTenifold_ma_dim": 2,
        "scTenifold_backend": "serial",
        "scTenifold_jobs": 1,
        "drugreflector_checkpoint_dir": None,
        "drugreflector_top_n": 50,
    },
    "network_toxicology": {
        "compound_name": None,
        "disease_name": None,
        "compound_targets_csv": None,
        "target_sources": None,
        "target_sources_dir": None,
        "disease_genes_csv": None,
        "disease_gene_column": None,
        "ppi_network_csv": None,
        "output_dir": "outputs/run_001/network_toxicology",
        "venn": True,
        "cytoscape": "auto",
        "cytoscape_url": "http://127.0.0.1:1234",
        "cytoscape_layout": "cose",
        "cytoscape_save_session": False,
        "max_ppi_edges": 2000,
        "run_enrichment": False,
        "enrichment_timeout": 900,
    },
    "faers": {
        "input_csv": None,
        "drug_column": "drug",
        "event_column": "event",
        "count_column": None,
        "min_count": 3,
        "output_dir": "outputs/run_001/faers",
    },
    "validation": {
        "top_n": 10,
        "output_dir": "outputs/run_001/validation",
    },
}


def deep_merge(base: dict, extra: dict) -> dict:
    out = copy.deepcopy(base)
    for key, value in (extra or {}).items():
        if isinstance(value, dict) and isinstance(out.get(key), dict):
            out[key] = deep_merge(out[key], value)
        else:
            out[key] = copy.deepcopy(value)
    return out


class ResolvedConfig:
    def __init__(self, data: dict, config_path: Path):
        self.data = data
        self.config_path = Path(config_path).resolve()
        self.root = self.config_path.parent
        env_workdir = os.environ.get("DOCK_WORKDIR")
        if env_workdir:
            data["workdir"] = env_workdir
        self.workdir = self._resolve(data.get("workdir") or ".", self.root)
        self.output_dir = self._resolve(
            data.get("output_dir") or "outputs/run_001", self.workdir
        )

    def _resolve(self, value, base: Path | None = None) -> Path:
        path = Path(str(value)).expanduser()
        if not path.is_absolute():
            path = (base or self.workdir) / path
        return path.resolve()

    def get(self, section: str, key: str, default=None):
        return self.data.get(section, {}).get(key, default)

    def receptor_input(self) -> Path:
        return self._resolve(self.get("receptor", "input"))

    def receptor_output(self) -> Path:
        return self._resolve(self.get("receptor", "output"))

    def receptor_center(self) -> list[float]:
        return [float(v) for v in self.get("receptor", "center", [0.0, 0.0, 0.0])]

    def receptor_size(self) -> list[float]:
        return [float(v) for v in self.get("receptor", "size", [22.5, 22.5, 22.5])]

    def receptor_flexible(self) -> list[Path]:
        return [
            self._resolve(str(item), self.workdir)
            for item in self.get("receptor", "flexible", [])
        ]

    def ligand_input(self) -> Path:
        return self._resolve(self.get("ligand", "input"))

    def ligand_output_dir(self) -> Path:
        return self._resolve(self.get("ligand", "output_dir"))

    def docked_dir(self) -> Path:
        return self.output_dir / "docked"

    def reports_dir(self) -> Path:
        return self.output_dir / "results"

    def analysis_dir(self) -> Path:
        return self.reports_dir() / "01_analysis"

    def redock_dir(self) -> Path:
        return self.reports_dir() / "02_redock"

    def ml_dir(self) -> Path:
        return self.reports_dir() / "03_ml"

    def knockout_dir(self) -> Path:
        return self.reports_dir() / "04_knockout"

    def validation_dir(self) -> Path:
        return self.reports_dir() / "05_validation"

    def logs_dir(self) -> Path:
        return self.output_dir / "logs"

    def stage_dir(self) -> Path:
        return self.output_dir / ".stages"

    def results_path(self) -> Path:
        return self.docked_dir() / "results.csv"

    def manifest_path(self) -> Path:
        return self.ligand_output_dir() / "manifest.csv"

    def ml_training_csv(self) -> Path:
        return self._resolve(self.get("ml", "training_csv", "data/ml/training.csv"))

    def md_export_dir(self) -> Path:
        return self._resolve(self.get("md", "export_dir", "outputs/md"))

    def md_dir(self) -> Path:
        return self.reports_dir() / "06_md"

    def _number(self, section: str, key: str, default: float) -> float:
        value = self.get(section, key, default)
        try:
            return float(value)
        except (TypeError, ValueError):
            raise ValueError(f"{section}.{key} must be a number") from None

    def validate(self) -> None:
        for name, values in [
            ("center", self.receptor_center()),
            ("size", self.receptor_size()),
        ]:
            if not isinstance(values, (list, tuple)) or len(values) != 3:
                raise ValueError(f"receptor.{name} must be a list of 3 numbers")
        if any(v <= 0 for v in self.receptor_size()):
            raise ValueError("receptor.size values must be positive")
        if any(v > 200.0 for v in self.receptor_size()):
            raise ValueError(
                "receptor.size values must be <= 200 Angstrom; a larger box "
                "usually means the wrong receptor or a unit mistake"
            )
        for section, key in [
            ("docking", "exhaustiveness"),
            ("docking", "num_modes"),
            ("docking", "cpu"),
            ("docking", "max_workers"),
        ]:
            if self._number(section, key, 0) < 1:
                raise ValueError(f"{section}.{key} must be >= 1")
        for section, key, default in [
            ("docking", "energy_range", 3.0),
            ("docking", "timeout_seconds", 600.0),
            ("redock", "exhaustiveness", 32.0),
            ("redock", "num_modes", 9.0),
            ("redock", "top_n", 20.0),
            ("redock", "energy_range", 3.0),
            ("redock", "max_workers", 4.0),
            ("redock", "timeout_seconds", 600.0),
        ]:
            if self._number(section, key, default) <= 0:
                raise ValueError(f"{section}.{key} must be positive")
        cutoff = self._number("analysis", "cutoff", -7.0)
        moderate = self._number("analysis", "moderate_cutoff", -5.0)
        if cutoff > moderate:
            raise ValueError(
                "analysis.cutoff must be <= analysis.moderate_cutoff"
            )
        if self._number("analysis", "top_n", 100) < 1:
            raise ValueError("analysis.top_n must be >= 1")
        tanimoto = self._number("analysis", "tanimoto_cutoff", 0.7)
        if not 0.0 <= tanimoto <= 1.0:
            raise ValueError(
                "analysis.tanimoto_cutoff must be between 0 and 1"
            )
        for section, key, minimum, strict in [
            ("md_simulation", "dt_ps", 0.0, True),
            ("md_simulation", "temperature", 0.0, True),
            ("md_simulation", "pressure", 0.0, True),
            ("md_simulation", "box_padding_nm", 0.0, True),
            ("md_simulation", "contact_cutoff_nm", 0.0, True),
            ("md_simulation", "prod_steps", 0.0, True),
            ("md_simulation", "timeout_seconds", 0.0, True),
            ("md_simulation", "ion_concentration", 0.0, False),
            ("md_simulation", "em_steps", 0.0, False),
            ("md_simulation", "equil_steps", 0.0, False),
            ("md_simulation", "top_n", 1.0, False),
            ("md_simulation", "cpu", 1.0, False),
            ("md", "top_n", 1.0, False),
        ]:
            value = self._number(section, key, minimum)
            if (strict and value <= minimum) or (
                not strict and value < minimum
            ):
                raise ValueError(
                    f"{section}.{key} must be "
                    f"{'>' if strict else '>='} {minimum:g}"
                )
        fraction = self._number("md_simulation", "equilibrate_fraction", 0.5)
        if not 0.0 <= fraction <= 1.0:
            raise ValueError(
                "md_simulation.equilibrate_fraction must be between 0 and 1"
            )
        if not 0.0 <= self._number("ligand", "ph", 7.4) <= 14.0:
            raise ValueError("ligand.ph must be between 0 and 14")
        if self._number("ligand", "max_heavy_atoms", 60) < 1:
            raise ValueError("ligand.max_heavy_atoms must be >= 1")
        if self._number("ligand", "max_rotatable_bonds", 15) < 0:
            raise ValueError("ligand.max_rotatable_bonds must be >= 0")
        if self._number("ligand", "conformers", 1) < 1:
            raise ValueError("ligand.conformers must be >= 1")
        max_ligands = self.get("ligand", "max_ligands")
        if max_ligands is not None and self._number(
            "ligand", "max_ligands", 1
        ) < 1:
            raise ValueError("ligand.max_ligands must be >= 1")
        test_size = self._number("ml", "test_size", 0.2)
        if not 0.0 < test_size < 1.0:
            raise ValueError("ml.test_size must be between 0 and 1")
        if self._number("ml", "epochs", 80) < 1:
            raise ValueError("ml.epochs must be >= 1")
        if self._number("ml", "hidden_size", 128) < 1:
            raise ValueError("ml.hidden_size must be >= 1")
        if self._number("evidence", "max_items", 10) < 1:
            raise ValueError("evidence.max_items must be >= 1")
        min_cells = self._number("insilico_knockout", "min_cells", 100)
        max_cells = self._number("insilico_knockout", "max_cells", 5000)
        if min_cells < 1:
            raise ValueError("insilico_knockout.min_cells must be >= 1")
        if max_cells < 1:
            raise ValueError("insilico_knockout.max_cells must be >= 1")
        if min_cells > max_cells:
            raise ValueError(
                "insilico_knockout.min_cells must be <= "
                "insilico_knockout.max_cells"
            )
        if self._number("insilico_knockout", "max_genes", 1800) < 1:
            raise ValueError("insilico_knockout.max_genes must be >= 1")
        if self._number("insilico_knockout", "n_propagation", 3) < 1:
            raise ValueError("insilico_knockout.n_propagation must be >= 1")
        if self._number("knockout", "top_n", 50) < 1:
            raise ValueError("knockout.top_n must be >= 1")
        if self._number("knockout", "max_genes", 2000) < 1:
            raise ValueError("knockout.max_genes must be >= 1")
        if self._number("knockout", "max_samples", 5000) < 1:
            raise ValueError("knockout.max_samples must be >= 1")
        corr_cutoff = self._number("knockout", "corr_cutoff", 0.7)
        if not -1.0 <= corr_cutoff <= 1.0:
            raise ValueError("knockout.corr_cutoff must be between -1 and 1")
        if self._number("network_toxicology", "max_ppi_edges", 2000) < 1:
            raise ValueError("network_toxicology.max_ppi_edges must be >= 1")
        if self._number("faers", "min_count", 3) < 1:
            raise ValueError("faers.min_count must be >= 1")
        if self._number("report", "top_n", 20) < 1:
            raise ValueError("report.top_n must be >= 1")
        if self._number("validation", "top_n", 10) < 1:
            raise ValueError("validation.top_n must be >= 1")


def load_config(
    config_path: str | Path | None = None,
    overrides: dict | None = None,
) -> ResolvedConfig:
    if config_path is None:
        config_path = (
            Path(__file__).resolve().parent.parent.parent
            / "config"
            / "docking_config.json"
        )
    config_path = Path(config_path).resolve()
    raw = {}
    if config_path.exists():
        text = config_path.read_text(encoding="utf-8")
        if config_path.suffix.lower() in (".yaml", ".yml"):
            if yaml is None:
                raise RuntimeError("PyYAML is required to load YAML docking configs")
            raw = yaml.safe_load(text) or {}
        else:
            raw = json.loads(text) or {}
    data = deep_merge(DEFAULTS, raw)
    cfg = ResolvedConfig(data, config_path)
    if overrides:
        cfg = apply_overrides(cfg, overrides)
    cfg.validate()
    return cfg


def apply_overrides(cfg: ResolvedConfig, overrides: dict) -> ResolvedConfig:
    data = cfg.data
    for key, dotted in [
        ("workdir", "workdir"),
        ("outdir", "output_dir"),
        ("receptor", "receptor/input"),
        ("ligand", "ligand/input"),
    ]:
        if overrides.get(key) is not None:
            set_dotted(data, dotted, overrides[key])

    section_map = {
        "center": ("receptor", "center"),
        "size": ("receptor", "size"),
        "flexible": ("receptor", "flexible"),
        "exhaustiveness": ("docking", "exhaustiveness"),
        "num_modes": ("docking", "num_modes"),
        "energy_range": ("docking", "energy_range"),
        "cpu": ("docking", "cpu"),
        "max_workers": ("docking", "max_workers"),
        "seed": ("docking", "seed"),
        "seeds": ("docking", "seeds"),
        "replicates": ("docking", "replicates"),
        "positive_control_pdbqt": ("docking", "positive_control_pdbqt"),
        "positive_control_id": ("docking", "positive_control_id"),
        "positive_control_max_affinity": (
            "docking",
            "positive_control_max_affinity",
        ),
        "scoring": ("docking", "scoring"),
        "executable": ("docking", "executable"),
        "max_ligands": ("ligand", "max_ligands"),
        "ligand_engine": ("ligand", "engine"),
        "conformers": ("ligand", "conformers"),
        "cutoff": ("analysis", "cutoff"),
        "moderate_cutoff": ("analysis", "moderate_cutoff"),
        "top_n": ("analysis", "top_n"),
        "figures": ("analysis", "figures"),
        "diversity": ("analysis", "diversity"),
        "model": ("ml", "model"),
        "label_column": ("ml", "label_column"),
        "training_csv": ("ml", "training_csv"),
        "epochs": ("ml", "epochs"),
        "hidden_size": ("ml", "hidden_size"),
        "md_mode": ("md_simulation", "mode"),
        "md_executable": ("md_simulation", "executable"),
        "md_gmx_data": ("md_simulation", "gmx_data_dir"),
        "md_top_n": ("md_simulation", "top_n"),
        "md_receptor_pdb": ("md_simulation", "receptor_pdb"),
        "md_protein_ff": ("md_simulation", "protein_forcefield"),
        "md_water": ("md_simulation", "water"),
        "md_em_steps": ("md_simulation", "em_steps"),
        "md_equil_steps": ("md_simulation", "equil_steps"),
        "md_prod_steps": ("md_simulation", "prod_steps"),
        "md_gen_seed": ("md_simulation", "gen_seed"),
        "md_temperature": ("md_simulation", "temperature"),
        "md_ligand_charge": ("md_simulation", "ligand_charge"),
        "md_cpu": ("md_simulation", "cpu"),
        "md_gpu": ("md_simulation", "gpu"),
        "md_maxwarn": ("md_simulation", "maxwarn"),
        "md_topology_dir": ("md_simulation", "topology_dir"),
        "md_mmpbsa_command": ("md_simulation", "mmpbsa_command"),
        "md_mmpbsa_timeout": (
            "md_simulation",
            "mmpbsa_timeout_seconds",
        ),
        "uniprot": ("evidence", "uniprot_accession"),
        "pdb": ("evidence", "pdb_id"),
        "chembl_target": ("evidence", "chembl_target_id"),
        "target_name": ("evidence", "target_name"),
        "ligand_name": ("evidence", "ligand_name"),
        "ligand_smiles": ("evidence", "ligand_smiles"),
        "max_items": ("evidence", "max_items"),
        "expression_csv": ("knockout", "expression_csv"),
        "metadata_csv": ("knockout", "metadata_csv"),
        "depmap_csv": ("knockout", "depmap_csv"),
        "prognosis_csv": ("knockout", "prognosis_csv"),
        "druggability_csv": ("knockout", "druggability_csv"),
        "off_target_csv": ("knockout", "off_target_csv"),
        "cell_type_column": ("knockout", "cell_type_column"),
        "group_column": ("knockout", "group_column"),
        "case_label": ("knockout", "case_label"),
        "normal_label": ("knockout", "normal_label"),
        "ko_top_n": ("knockout", "top_n"),
        "validation_top_n": ("validation", "top_n"),
        "insilico_gene": ("insilico_knockout", "ko_gene"),
        "insilico_engine": ("insilico_knockout", "engine"),
        "insilico_raw_count_input": (
            "insilico_knockout",
            "raw_count_input",
        ),
        "insilico_species": ("insilico_knockout", "species"),
        "insilico_embedding_csv": ("insilico_knockout", "embedding_csv"),
        "insilico_regulators_csv": ("insilico_knockout", "regulators_csv"),
        "insilico_photo_dir": ("insilico_knockout", "photo_output_dir"),
        "compound_name": ("network_toxicology", "compound_name"),
        "disease_name": ("network_toxicology", "disease_name"),
        "compound_targets_csv": ("network_toxicology", "compound_targets_csv"),
        "target_sources_dir": ("network_toxicology", "target_sources_dir"),
        "disease_genes_csv": ("network_toxicology", "disease_genes_csv"),
        "disease_gene_column": ("network_toxicology", "disease_gene_column"),
        "network_output_dir": ("network_toxicology", "output_dir"),
        "venn": ("network_toxicology", "venn"),
        "network_cytoscape": ("network_toxicology", "cytoscape"),
        "network_cytoscape_url": ("network_toxicology", "cytoscape_url"),
        "network_cytoscape_layout": ("network_toxicology", "cytoscape_layout"),
        "network_cytoscape_session": (
            "network_toxicology",
            "cytoscape_save_session",
        ),
        "network_max_ppi_edges": ("network_toxicology", "max_ppi_edges"),
        "run_enrichment": ("network_toxicology", "run_enrichment"),
        "enrichment_timeout": ("network_toxicology", "enrichment_timeout"),
        "faers_input": ("faers", "input_csv"),
        "faers_drug_column": ("faers", "drug_column"),
        "faers_event_column": ("faers", "event_column"),
        "faers_count_column": ("faers", "count_column"),
        "faers_min_count": ("faers", "min_count"),
    }
    for key, (section, field) in section_map.items():
        if overrides.get(key) is not None:
            data.setdefault(section, {})[field] = overrides[key]
    if overrides.get("ppi_network_csv") is not None:
        data.setdefault("knockout", {})["ppi_network_csv"] = overrides[
            "ppi_network_csv"
        ]
        data.setdefault("network_toxicology", {})["ppi_network_csv"] = overrides[
            "ppi_network_csv"
        ]
    return ResolvedConfig(data, cfg.config_path)


def set_dotted(data: dict, dotted: str, value) -> None:
    parts = dotted.split("/")
    target = data
    for part in parts[:-1]:
        target = target.setdefault(part, {})
    target[parts[-1]] = value


def save_config(
    cfg: ResolvedConfig,
    path: Path,
    sections: list[str] | None = None,
    posix_paths: bool = False,
    strict_relative: bool = False,
) -> None:
    """Serialize the resolved config.

    ``sections`` keeps only the named top-level keys (used by the standalone
    molecular docking board, which manages a subset of the full config).
    ``posix_paths`` writes forward-slash relative paths and
    ``strict_relative`` only relativizes paths inside the workdir.
    """
    def _rel_path(value: Path) -> str:
        return _rel(value, cfg.workdir, strict_relative)

    data = {
        "name": cfg.data.get("name", "virtual_screening"),
        "workdir": str(cfg.workdir),
        "output_dir": _rel_path(cfg.output_dir),
        "receptor": {
            "input": _rel_path(cfg.receptor_input()),
            "output": _rel_path(cfg.receptor_output()),
            "detect_input": cfg.get("receptor", "detect_input"),
            "center": cfg.receptor_center(),
            "size": cfg.receptor_size(),
            "flexible": [_rel_path(item) for item in cfg.receptor_flexible()],
        },
        "ligand": {
            "input": _rel_path(cfg.ligand_input()),
            "output_dir": _rel_path(cfg.ligand_output_dir()),
            "smiles_column": cfg.get("ligand", "smiles_column", "SMILES"),
            "id_column": cfg.get("ligand", "id_column", "ID"),
            "ph": cfg.get("ligand", "ph", 7.4),
            "remove_salts": cfg.get("ligand", "remove_salts", True),
            "neutralize": cfg.get("ligand", "neutralize", True),
            "max_heavy_atoms": cfg.get("ligand", "max_heavy_atoms", 60),
            "max_rotatable_bonds": cfg.get("ligand", "max_rotatable_bonds", 15),
            "max_ligands": cfg.get("ligand", "max_ligands", None),
            "conformers": cfg.get("ligand", "conformers", 1),
            "seed": cfg.get("ligand", "seed", 42),
            "engine": cfg.get("ligand", "engine", "auto"),
        },
        "docking": {
            "engine": cfg.get("docking", "engine", "vina"),
            "executable": cfg.get("docking", "executable", "vina"),
            "scoring": cfg.get("docking", "scoring", "vina"),
            "exhaustiveness": cfg.get("docking", "exhaustiveness", 8),
            "num_modes": cfg.get("docking", "num_modes", 9),
            "energy_range": cfg.get("docking", "energy_range", 3.0),
            "cpu": cfg.get("docking", "cpu", 4),
            "max_workers": cfg.get("docking", "max_workers", 4),
            "seed": cfg.get("docking", "seed", 42),
            "seeds": cfg.get("docking", "seeds", []),
            "replicates": cfg.get("docking", "replicates", 1),
            "positive_control_pdbqt": cfg.get(
                "docking",
                "positive_control_pdbqt",
                None,
            ),
            "positive_control_id": cfg.get(
                "docking",
                "positive_control_id",
                "positive_control",
            ),
            "positive_control_max_affinity": cfg.get(
                "docking",
                "positive_control_max_affinity",
                None,
            ),
            "timeout_seconds": cfg.get("docking", "timeout_seconds", 600),
            "resume": cfg.get("docking", "resume", True),
        },
        "analysis": {
            "cutoff": cfg.get("analysis", "cutoff", -7.0),
            "moderate_cutoff": cfg.get("analysis", "moderate_cutoff", -5.0),
            "top_n": cfg.get("analysis", "top_n", 100),
            "figures": cfg.get("analysis", "figures", True),
            "diversity": cfg.get("analysis", "diversity", True),
            "tanimoto_cutoff": cfg.get("analysis", "tanimoto_cutoff", 0.7),
        },
        "evidence": {
            "uniprot_accession": cfg.get("evidence", "uniprot_accession"),
            "pdb_id": cfg.get("evidence", "pdb_id"),
            "chembl_target_id": cfg.get("evidence", "chembl_target_id"),
            "target_name": cfg.get("evidence", "target_name"),
            "ligand_name": cfg.get("evidence", "ligand_name"),
            "ligand_smiles": cfg.get("evidence", "ligand_smiles"),
            "max_items": cfg.get("evidence", "max_items", 10),
        },
        "ml": {
            "model": cfg.get("ml", "model", "rf"),
            "task": cfg.get("ml", "task", "auto"),
            "label_column": cfg.get("ml", "label_column", "active"),
            "training_csv": cfg.get("ml", "training_csv", "data/ml/training.csv"),
            "test_size": cfg.get("ml", "test_size", 0.2),
            "random_state": cfg.get("ml", "random_state", 42),
            "epochs": cfg.get("ml", "epochs", 80),
            "hidden_size": cfg.get("ml", "hidden_size", 128),
        },
        "md": {
            "export_dir": cfg.get("md", "export_dir", "outputs/md"),
            "top_n": cfg.get("md", "top_n", 10),
        },
        "md_simulation": {
            "mode": cfg.get("md_simulation", "mode", "prepare"),
            "executable": cfg.get("md_simulation", "executable"),
            "gmx_data_dir": cfg.get("md_simulation", "gmx_data_dir"),
            "top_n": cfg.get("md_simulation", "top_n", 1),
            "receptor_pdb": cfg.get("md_simulation", "receptor_pdb"),
            "protein_forcefield": cfg.get(
                "md_simulation", "protein_forcefield", "amber99sb-ildn"
            ),
            "water": cfg.get("md_simulation", "water", "tip3p"),
            "box_type": cfg.get("md_simulation", "box_type", "cubic"),
            "box_padding_nm": cfg.get(
                "md_simulation", "box_padding_nm", 1.2
            ),
            "ion_concentration": cfg.get(
                "md_simulation", "ion_concentration", 0.15
            ),
            "ligand_charge": cfg.get("md_simulation", "ligand_charge", 0),
            "ligand_forcefield": cfg.get(
                "md_simulation", "ligand_forcefield", "gaff2"
            ),
            "topology_dir": cfg.get("md_simulation", "topology_dir"),
            "em_steps": cfg.get("md_simulation", "em_steps", 5000),
            "equil_steps": cfg.get("md_simulation", "equil_steps", 250000),
            "prod_steps": cfg.get("md_simulation", "prod_steps", 25000000),
            "dt_ps": cfg.get("md_simulation", "dt_ps", 0.002),
            "gen_seed": cfg.get("md_simulation", "gen_seed", 42),
            "temperature": cfg.get("md_simulation", "temperature", 300),
            "pressure": cfg.get("md_simulation", "pressure", 1.0),
            "timeout_seconds": cfg.get(
                "md_simulation", "timeout_seconds", 86400
            ),
            "cpu": cfg.get("md_simulation", "cpu", 4),
            "gpu": cfg.get("md_simulation", "gpu", False),
            "figures": cfg.get("md_simulation", "figures", True),
            "maxwarn": cfg.get("md_simulation", "maxwarn", 20),
            "contact_cutoff_nm": cfg.get(
                "md_simulation", "contact_cutoff_nm", 0.6
            ),
            "equilibrate_fraction": cfg.get(
                "md_simulation", "equilibrate_fraction", 0.5
            ),
            "mmpbsa_command": cfg.get(
                "md_simulation", "mmpbsa_command", None
            ),
            "mmpbsa_timeout_seconds": cfg.get(
                "md_simulation", "mmpbsa_timeout_seconds", 7200
            ),
            "rmsd_stable_std_nm": cfg.get(
                "md_simulation", "rmsd_stable_std_nm", 0.15
            ),
            "rg_stable_std_nm": cfg.get(
                "md_simulation", "rg_stable_std_nm", 0.05
            ),
            "sasa_stable_std_nm2": cfg.get(
                "md_simulation", "sasa_stable_std_nm2", 1.0
            ),
        },
        "redock": {
            "enabled": cfg.get("redock", "enabled", True),
            "top_n": cfg.get("redock", "top_n", 20),
            "exhaustiveness": cfg.get("redock", "exhaustiveness", 32),
            "num_modes": cfg.get("redock", "num_modes", 9),
            "energy_range": cfg.get("redock", "energy_range", 3.0),
            "max_workers": cfg.get("redock", "max_workers", 4),
            "timeout_seconds": cfg.get("redock", "timeout_seconds", 600),
            "resume": cfg.get("redock", "resume", True),
        },
        "report": {
            "top_n": cfg.get("report", "top_n", 20),
        },
        "knockout": {
            "enabled": cfg.get("knockout", "enabled", True),
            "expression_csv": cfg.get(
                "knockout", "expression_csv", "data/knockout/expression.csv"
            ),
            "metadata_csv": cfg.get("knockout", "metadata_csv"),
            "ppi_network_csv": cfg.get("knockout", "ppi_network_csv"),
            "depmap_csv": cfg.get("knockout", "depmap_csv"),
            "prognosis_csv": cfg.get("knockout", "prognosis_csv"),
            "druggability_csv": cfg.get("knockout", "druggability_csv"),
            "off_target_csv": cfg.get("knockout", "off_target_csv"),
            "group_column": cfg.get("knockout", "group_column", "condition"),
            "cell_type_column": cfg.get("knockout", "cell_type_column"),
            "case_label": cfg.get("knockout", "case_label"),
            "normal_label": cfg.get("knockout", "normal_label"),
            "top_n": cfg.get("knockout", "top_n", 50),
            "figures": cfg.get("knockout", "figures", True),
            "max_genes": cfg.get("knockout", "max_genes", 2000),
            "max_samples": cfg.get("knockout", "max_samples", 5000),
            "corr_cutoff": cfg.get("knockout", "corr_cutoff", 0.7),
            "liver_lineage": cfg.get("knockout", "liver_lineage", "liver"),
            "off_target_penalty": cfg.get("knockout", "off_target_penalty", 0.05),
            "disease_up_genes": cfg.get("knockout", "disease_up_genes"),
            "disease_down_genes": cfg.get("knockout", "disease_down_genes"),
            "pathway_genes": cfg.get("knockout", "pathway_genes"),
            "weights": cfg.get(
                "knockout",
                "weights",
                {
                    "expression": 0.35,
                    "proliferation": 0.25,
                    "network": 0.20,
                    "depmap": 0.20,
                },
            ),
            "target_weights": cfg.get(
                "knockout",
                "target_weights",
                {
                    "base": 0.35,
                    "reversal": 0.20,
                    "pathway": 0.15,
                    "specificity": 0.10,
                    "prognosis": 0.10,
                    "druggability": 0.10,
                    "ppi_hub": 0.10,
                },
            ),
        },
        "insilico_knockout": {
            "enabled": cfg.get("insilico_knockout", "enabled", False),
            "ko_gene": cfg.get("insilico_knockout", "ko_gene"),
            "engine": cfg.get("insilico_knockout", "engine", "auto"),
            "raw_count_input": cfg.get(
                "insilico_knockout", "raw_count_input"
            ),
            "species": cfg.get("insilico_knockout", "species", "auto"),
            "embedding_csv": cfg.get("insilico_knockout", "embedding_csv"),
            "regulators_csv": cfg.get("insilico_knockout", "regulators_csv"),
            "min_cells": cfg.get("insilico_knockout", "min_cells", 100),
            "max_cells": cfg.get("insilico_knockout", "max_cells", 5000),
            "max_genes": cfg.get("insilico_knockout", "max_genes", 1800),
            "n_propagation": cfg.get(
                "insilico_knockout", "n_propagation", 3
            ),
            "network_edges_per_regulator": cfg.get(
                "insilico_knockout", "network_edges_per_regulator", 300
            ),
            "target_top_n": cfg.get("insilico_knockout", "target_top_n", 15),
            "bar_top_n": cfg.get("insilico_knockout", "bar_top_n", 8),
            "run_enrichment": cfg.get(
                "insilico_knockout", "run_enrichment", True
            ),
            "enrichment_genes": cfg.get(
                "insilico_knockout", "enrichment_genes", 150
            ),
            "gene_note": cfg.get("insilico_knockout", "gene_note"),
            "photo_output_dir": cfg.get(
                "insilico_knockout", "photo_output_dir"
            ),
            "figures": cfg.get("insilico_knockout", "figures", True),
            "scTenifold_min_lib_size": cfg.get(
                "insilico_knockout", "scTenifold_min_lib_size", 1000
            ),
            "scTenifold_remove_outlier_cells": cfg.get(
                "insilico_knockout", "scTenifold_remove_outlier_cells", True
            ),
            "scTenifold_min_percent": cfg.get(
                "insilico_knockout", "scTenifold_min_percent", 0.05
            ),
            "scTenifold_max_mito_ratio": cfg.get(
                "insilico_knockout", "scTenifold_max_mito_ratio", 0.1
            ),
            "scTenifold_min_exp_avg": cfg.get(
                "insilico_knockout", "scTenifold_min_exp_avg", 0.05
            ),
            "scTenifold_min_exp_sum": cfg.get(
                "insilico_knockout", "scTenifold_min_exp_sum", 25
            ),
            "scTenifold_n_networks": cfg.get(
                "insilico_knockout", "scTenifold_n_networks", 5
            ),
            "scTenifold_n_cells": cfg.get(
                "insilico_knockout", "scTenifold_n_cells", 500
            ),
            "scTenifold_n_comp": cfg.get(
                "insilico_knockout", "scTenifold_n_comp", 3
            ),
            "scTenifold_q": cfg.get("insilico_knockout", "scTenifold_q", 0.95),
            "scTenifold_K": cfg.get("insilico_knockout", "scTenifold_K", 3),
            "scTenifold_ma_dim": cfg.get(
                "insilico_knockout", "scTenifold_ma_dim", 2
            ),
            "scTenifold_backend": cfg.get(
                "insilico_knockout", "scTenifold_backend", "serial"
            ),
            "scTenifold_jobs": cfg.get(
                "insilico_knockout", "scTenifold_jobs", 1
            ),
            "drugreflector_checkpoint_dir": cfg.get(
                "insilico_knockout", "drugreflector_checkpoint_dir"
            ),
            "drugreflector_top_n": cfg.get(
                "insilico_knockout", "drugreflector_top_n", 50
            ),
        },
        "network_toxicology": {
            "compound_name": cfg.get("network_toxicology", "compound_name"),
            "disease_name": cfg.get("network_toxicology", "disease_name"),
            "compound_targets_csv": cfg.get(
                "network_toxicology", "compound_targets_csv"
            ),
            "target_sources": cfg.get("network_toxicology", "target_sources"),
            "disease_genes_csv": cfg.get(
                "network_toxicology", "disease_genes_csv"
            ),
            "disease_gene_column": cfg.get(
                "network_toxicology", "disease_gene_column"
            ),
            "ppi_network_csv": cfg.get("network_toxicology", "ppi_network_csv"),
            "output_dir": cfg.get(
                "network_toxicology",
                "output_dir",
                "outputs/run_001/network_toxicology",
            ),
            "venn": cfg.get("network_toxicology", "venn", True),
            "cytoscape": cfg.get(
                "network_toxicology",
                "cytoscape",
                "auto",
            ),
            "cytoscape_url": cfg.get(
                "network_toxicology",
                "cytoscape_url",
                "http://127.0.0.1:1234",
            ),
            "cytoscape_layout": cfg.get(
                "network_toxicology",
                "cytoscape_layout",
                "cose",
            ),
            "cytoscape_save_session": cfg.get(
                "network_toxicology",
                "cytoscape_save_session",
                False,
            ),
            "max_ppi_edges": cfg.get(
                "network_toxicology",
                "max_ppi_edges",
                2000,
            ),
        },
        "faers": {
            "input_csv": cfg.get("faers", "input_csv"),
            "drug_column": cfg.get("faers", "drug_column", "drug"),
            "event_column": cfg.get("faers", "event_column", "event"),
            "count_column": cfg.get("faers", "count_column"),
            "min_count": cfg.get("faers", "min_count", 3),
            "output_dir": cfg.get(
                "faers", "output_dir", "outputs/run_001/faers"
            ),
        },
        "validation": {
            "top_n": cfg.get("validation", "top_n", 10),
            "output_dir": cfg.get(
                "validation", "output_dir", "outputs/run_001/validation"
            ),
        },
    }
    if sections is not None:
        data = {key: value for key, value in data.items() if key in sections}
    if posix_paths:
        data = _posix_paths(data)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _posix_paths(value):
    if isinstance(value, dict):
        return {key: _posix_paths(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_posix_paths(item) for item in value]
    if isinstance(value, str):
        return value.replace("\\", "/")
    return value


def _rel(path: Path, base: Path, strict: bool = False) -> str:
    if strict:
        try:
            return path.resolve().relative_to(Path(base).resolve()).as_posix()
        except ValueError:
            return str(path)
    try:
        return os.path.relpath(path, base)
    except ValueError:
        return str(path)
