"""Virtual screening (molecular docking) pipeline for liver cancer targets."""

__version__ = "1.7.1"
