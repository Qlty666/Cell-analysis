"""Pipeline orchestration module."""
